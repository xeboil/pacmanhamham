package de.janiswolf._pacman.entities;

public class Position {
    public int x,y;
    public Position(int x,int y){
        this.x = x;
        this.y = y;

    }

}
