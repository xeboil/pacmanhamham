package de.janiswolf._pacman.entities;

public enum EntityType {
    PLAYER, DOG, DOG_INTERCEPTOR, SPEED_DOG, NO_COLLISION_DOG
}
